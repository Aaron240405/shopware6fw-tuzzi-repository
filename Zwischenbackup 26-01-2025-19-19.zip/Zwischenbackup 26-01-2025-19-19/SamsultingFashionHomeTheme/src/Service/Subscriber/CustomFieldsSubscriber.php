<?php declare(strict_types=1);

namespace SamsultingFashionHomeTheme\Service\Subscriber;

use Shopware\Core\Framework\DataAbstractionLayer\Event\EntityLoadedEvent;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Shopware\Core\Content\Product\ProductEvents;
use Shopware\Core\Content\Category\CategoryEvents;
use Shopware\Core\System\SalesChannel\Event\SalesChannelContextCreatedEvent;

class CustomFieldsSubscriber implements EventSubscriberInterface
{
    private SystemConfigService $systemConfigService;

    public function __construct(SystemConfigService $systemConfigService)
    {
        $this->systemConfigService = $systemConfigService;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            ProductEvents::PRODUCT_LOADED_EVENT => 'onProductLoaded',
            CategoryEvents::CATEGORY_LOADED_EVENT => 'onCategoryLoaded',
            'sales_channel.context.created' => 'onSalesChannelContextCreated'
        ];
    }

    public function onProductLoaded(EntityLoadedEvent $event): void
    {
        foreach ($event->getEntities() as $product) {
            if ($product->getCustomFields() === null) {
                // Wenn das Produkt keine eigenen Custom Fields hat,
                // versuche die der übergeordneten Kategorie zu verwenden
                $customFields = [];
                if ($product->getCategories()) {
                    foreach ($product->getCategories() as $category) {
                        $categoryCustomFields = $category->getCustomFields();
                        if (isset($categoryCustomFields['custom_seo_text_title'])) {
                            $customFields = $categoryCustomFields;
                            break;
                        }
                    }
                }

                if (empty($customFields)) {
                    $customFields = [
                        'custom_seo_text_title' => '',
                        'custom_seo_text_text' => ''
                    ];
                }
                
                $product->setCustomFields($customFields);
            }
        }
    }

    public function onCategoryLoaded(EntityLoadedEvent $event): void
    {
        foreach ($event->getEntities() as $category) {
            if ($category->getCustomFields() === null) {
                $category->setCustomFields([
                    'custom_seo_text_title' => '',
                    'custom_seo_text_text' => ''
                ]);
            }
        }
    }

    public function onSalesChannelContextCreated(SalesChannelContextCreatedEvent $event): void
    {
        $salesChannel = $event->getSalesChannelContext()->getSalesChannel();
        if ($salesChannel && !$salesChannel->getCustomFields()) {
            $salesChannel->setCustomFields([
                'custom_seo_text_title' => '',
                'custom_seo_text_text' => ''
            ]);
        }
    }
}
<?php declare(strict_types=1);

namespace SamsultingFashionHomeTheme\Service\Subscriber;

use Shopware\Core\Content\Cms\Events\CmsPageLoadedEvent;
use Shopware\Core\Content\Cms\DataResolver\CmsSlotEntity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Shopware\Core\Content\Product\SalesChannel\SalesChannelProductEntity;
use Shopware\Core\System\SalesChannel\Entity\SalesChannelRepository;

class CustomProductGridCmsSubscriber implements EventSubscriberInterface
{
    private SalesChannelRepository $productRepository;
    private EntityRepository $mediaRepository;

    public function __construct(
        SalesChannelRepository $productRepository,
        EntityRepository $mediaRepository
    ) {
        $this->productRepository = $productRepository;
        $this->mediaRepository = $mediaRepository;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CmsPageLoadedEvent::class => 'onCmsPageLoaded'
        ];
    }

    private const LOG_FILE = '/var/www/sw6-test-frankwalder-com_shopware6/htdocs/custom/plugins/SamsultingFashionHomeTheme/logs/custom_grid_debug.log';

    public function onCmsPageLoaded(CmsPageLoadedEvent $event): void
    {
        $pages = $event->getResult();
        $context = $event->getContext();

        foreach ($pages as $page) {
            foreach ($page->getSections() as $section) {
                foreach ($section->getBlocks() as $block) {
                    foreach ($block->getSlots() as $slot) {
                        if ($slot->getType() !== 'custom-product-grid') {
                            continue;
                        }


                        $data = $slot->getData() ?? new CmsSlotEntity();
                        $config = $slot->getConfig() ?? [];
                        $customRows = $slot->getConfig()['customRows']['value'] ?? [];
                        if (empty($customRows)) {
                            continue;
                        }

                        // Sammle alle Produkt-IDs und Media-IDs
                        $productIds = [];
                        $mediaIds = [];
                        foreach ($customRows as $row) {
                            if (!empty($row['products']) && is_array($row['products'])) {
                                // Nur definierte und nicht-leere Produkt-IDs sammeln
                                foreach ($row['products'] as $productId) {
                                    if ($productId && !empty($productId)) {
                                        $productIds[] = $productId;
                                    }
                                }
                            }

                            if (!empty($row['stoerer']['mediaId'])) {
                                $mediaIds[] = $row['stoerer']['mediaId'];
                                // Debug für Media IDs
                                file_put_contents(self::LOG_FILE,
                                    "\nStörer Media ID gefunden:\n" .
                                    "Row Type: " . $row['type'] . "\n" .
                                    "Media ID: " . $row['stoerer']['mediaId'] . "\n",
                                    FILE_APPEND
                                );
                            }
                        }

                        file_put_contents(self::LOG_FILE,
                            "Tatsächlich konfigurierte Produkt-IDs:\n" .
                            print_r($productIds, true) . "\n",
                            FILE_APPEND
                        );

                        if (!empty($productIds)) {
                            $criteria = new Criteria($productIds);
                            $criteria->addAssociation('cover');
                            $criteria->addAssociation('price');
                            $criteria->addAssociation('prices');
                            $criteria->addAssociation('prices.currency');
                            $criteria->addAssociation('calculatedPrice');
                            $criteria->addAssociation('calculatedPrices');
                            $criteria->addAssociation('manufacturer');
                            
                            $salesChannelContext = $event->getSalesChannelContext();
                            $products = $this->productRepository->search($criteria, $salesChannelContext);
                            
                            // Debug output anpassen
                            file_put_contents(
                                self::LOG_FILE,
                                "\n=== Alle Produkte mit Preisen ===\n",
                                FILE_APPEND
                            );
                            
                            foreach ($products as $product) {
                                file_put_contents(
                                    self::LOG_FILE,
                                    "\nProdukt: " . $product->getName() . "\n" .
                                    "Price: " . print_r($product->getPrice(), true) . "\n" .
                                    "Calculated Price: " . print_r($product->getCalculatedPrice(), true) . "\n" .
                                    "----------------------------------------\n",
                                    FILE_APPEND
                                );
                            }
                        }

                        // Lade alle Störer-Medien
                        $mediaItems = new EntityCollection();
                        if (!empty($mediaIds)) {
                            $mediaCriteria = new Criteria($mediaIds);
                            $mediaItems = $this->mediaRepository->search($mediaCriteria, $context);

                            // Debug für geladene Medien
                            file_put_contents(self::LOG_FILE,
                                "\nGeladene Medien:\n" .
                                print_r($mediaItems->getIds(), true) . "\n",
                                FILE_APPEND
                            );
                        }

                        // Aktualisiere die Konfiguration mit den geladenen Daten
                        $slot->getConfig()['customRows']['value'] = $customRows;

                        // Füge die geladenen Entitäten den Rows hinzu
                        foreach ($customRows as &$row) {
                            // Füge Produkte hinzu
                            $rowProducts = [];
                            if (!empty($row['products'])) {
                                foreach ($row['products'] as $position => $productId) {
                                    if ($productId && $products->has($productId)) {
                                        $rowProducts[$position] = $products->get($productId);
                                    }
                                }
                            }
                            $row['productObjects'] = $rowProducts;

                            // Füge Störer-Bild hinzu
                            if (!empty($row['stoerer']['mediaId']) && $mediaItems->has($row['stoerer']['mediaId'])) {
                                $row['stoerer']['mediaObject'] = $mediaItems->get($row['stoerer']['mediaId']);
                            }
                        }

                        // Speichere die aktualisierten Rows zurück in den Slot
                        $data->customRows = $customRows;
                        $slot->setData($data);
                    }
                }
            }
        }
    }
}
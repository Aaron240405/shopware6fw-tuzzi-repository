<?php declare(strict_types=1);

namespace SamsultingFashionHomeTheme\Service\Subscriber;

use Shopware\Core\Content\Product\Events\ProductListingCriteriaEvent;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class ProductBoxSubscriber implements EventSubscriberInterface
{
    private EntityRepository $productRepository;

    public function __construct(EntityRepository $productRepository) 
    {
        $this->productRepository = $productRepository;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            ProductListingCriteriaEvent::class => ['handleListingRequest', 1000]
        ];
    }

    public function handleListingRequest(ProductListingCriteriaEvent $event): void
    {
        $criteria = $event->getCriteria();
        $criteria->addAssociation('media');
        $criteria->addAssociation('media.thumbnails');
        $criteria->addAssociation('cover.media');
        $criteria->addAssociation('children');
        $criteria->addAssociation('children.cover');
        $criteria->addAssociation('configuratorSettings');
        $criteria->addAssociation('options.group');
    }
}
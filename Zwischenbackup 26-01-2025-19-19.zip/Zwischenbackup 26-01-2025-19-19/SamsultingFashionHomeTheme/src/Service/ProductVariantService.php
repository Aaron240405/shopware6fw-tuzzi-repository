<?php declare(strict_types=1);

namespace SamsultingFashionHomeTheme\Service;

use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\Context;

class ProductVariantService
{
    private EntityRepository $productRepository;
    private EntityRepository $propertyGroupOptionRepository;

    public function __construct(
        EntityRepository $productRepository,
        EntityRepository $propertyGroupOptionRepository
    ) {
        $this->productRepository = $productRepository;
        $this->propertyGroupOptionRepository = $propertyGroupOptionRepository;
    }

    public function getVariantOptions(string $productId, Context $context): array
    {
        $criteria = new Criteria();
        $criteria->addAssociation('options.group');
        $criteria->addAssociation('options.media');

        $result = $this->productRepository->search($criteria, $context);
        $product = $result->get($productId);

        if (!$product || !$product->getOptions()) {
            return [];
        }

        $options = [];
        foreach ($product->getOptions() as $option) {
            $groupName = $option->getGroup()->getName();
            $options[$groupName][] = [
                'id' => $option->getId(),
                'name' => $option->getName(),
                'media' => $option->getMedia(),
                'color' => $option->getColorHexCode()
            ];
        }

        return $options;
    }
}
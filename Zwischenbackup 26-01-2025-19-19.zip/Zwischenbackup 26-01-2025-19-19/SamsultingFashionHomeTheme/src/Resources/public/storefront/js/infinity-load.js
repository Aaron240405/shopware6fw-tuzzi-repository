(function() {
    const InfinityLoad = {
        init: function() {
            this.listing = document.querySelector('.cms-element-product-listing-wrapper');
            if (!this.listing) return;
            
            this.itemsPerPage = 4;
            this.currentOffset = this.itemsPerPage;
            this.setupLoadMoreArea();
            this.setupSortingListener();
            this.updateProductCount();
        },

        setupLoadMoreArea: function() {
            const loadMoreArea = document.createElement('nav');
            loadMoreArea.className = 'sim-load-more-area flex flex-col items-center gap-2 mt-8';
            loadMoreArea.setAttribute('aria-label', 'Pagination Navigation');
            loadMoreArea.innerHTML = `
                <span class="product-count"></span>
                <div class="sim-progress-bar">
                    <div class="sim-progress-bar__indicator"></div>
                </div>
                <button class="btn btn-primary btn-load-more mt-6" id="loadMoreProducts">
                    Weitere Produkte laden
                </button>
            `;
            
            this.listing.appendChild(loadMoreArea);
            this.setupLoadMoreButton();

            // Initial alle Produkte außer die ersten 4 ausblenden
            const allProducts = this.listing.querySelectorAll('.cms-listing-row [role="listitem"]');
            Array.from(allProducts).slice(this.itemsPerPage).forEach(product => {
                product.style.display = 'none';
            });
        },

        setupLoadMoreButton: function() {
            const button = document.getElementById('loadMoreProducts');
            if (!button) return;

            button.addEventListener('click', () => {
                const allProducts = this.listing.querySelectorAll('.cms-listing-row [role="listitem"]');
                const hiddenProducts = Array.from(allProducts).filter(product => product.style.display === 'none');
                
                // Nächste 4 Produkte anzeigen
                hiddenProducts.slice(0, this.itemsPerPage).forEach(product => {
                    product.style.display = '';
                });

                this.currentOffset += this.itemsPerPage;
                this.updateProductCount();

                // Button ausblenden wenn keine weiteren Produkte
                if (hiddenProducts.length <= this.itemsPerPage) {
                    button.style.display = 'none';
                }
            });
        },

        getTotalProductCount: function() {
            return this.listing.querySelectorAll('.cms-listing-row [role="listitem"]').length;
        },

        getVisibleProductCount: function() {
            return Array.from(this.listing.querySelectorAll('.cms-listing-row [role="listitem"]'))
                .filter(product => product.style.display !== 'none').length;
        },

        updateProductCount: function() {
            const visibleCount = this.getVisibleProductCount();
            const totalCount = this.getTotalProductCount();
            
            const countDisplay = document.querySelector('.product-count');
            if (countDisplay) {
                countDisplay.textContent = `${visibleCount} von ${totalCount} Artikeln angezeigt`;
            }

            const progress = (visibleCount / totalCount) * 100;
            const progressBar = document.querySelector('.sim-progress-bar__indicator');
            if (progressBar) {
                progressBar.style.width = `${progress}%`;
            }
        },

        getTotalProductCount: function() {
            const productCountElement = document.querySelector('[data-listing-count]');
            return productCountElement ? parseInt(productCountElement.dataset.listingCount) : 0;
        }
    };
 
    // Style injection
    const style = document.createElement('style');
    style.textContent = `
        .sim-progress-bar {
            width: 100%;
            max-width: 300px;
            height: 4px;
            background: #e9ecef;
            border-radius: 2px;
            margin: 10px 0;
        }
 
        .sim-progress-bar__indicator {
            height: 100%;
            background: #007bff;
            border-radius: 2px;
            transition: width 0.3s ease;
        }
 
        .sim-load-more-area {
            text-align: center;
            margin: 30px 0;
        }
 
        .product-count {
            font-size: 14px;
            color: #6c757d;
        }
    `;
    document.head.appendChild(style);
 
    document.addEventListener('DOMContentLoaded', () => InfinityLoad.init());
 })();
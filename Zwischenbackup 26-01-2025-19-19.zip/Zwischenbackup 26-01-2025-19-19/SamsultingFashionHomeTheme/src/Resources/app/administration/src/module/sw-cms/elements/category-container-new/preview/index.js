import template from './sw-cms-el-preview-category-container.html.twig';
import './sw-cms-el-preview-category-container.scss';

const { Component } = Shopware;

Component.register('sw-cms-el-preview-image', {
    template
});
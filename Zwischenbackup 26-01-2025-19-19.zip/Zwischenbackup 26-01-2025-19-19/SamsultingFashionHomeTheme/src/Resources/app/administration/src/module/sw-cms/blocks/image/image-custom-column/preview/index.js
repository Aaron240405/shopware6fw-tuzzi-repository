import template from './sw-cms-preview-image-custom-column.html.twig';
import './sw-cms-preview-image-custom-column.scss';

/**
 * @private
 * @package buyers-experience
 */
export default {
    template,

    compatConfig: Shopware.compatConfig,

    computed: {
        assetFilter() {
            return Shopware.Filter.getByName('asset');
        },
    },
};

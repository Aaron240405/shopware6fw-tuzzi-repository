// SamsultingFashionHomeTheme/src/Resources/app/administration/src/module/sw-cms/constant/sw-cms.constant.js

export default {
    MEDIA: {
        previewMountain: '/administration/static/img/cms/preview_mountain_large.jpg',
        previewMountainSmall: '/administration/static/img/cms/preview_mountain_small.jpg',
        previewPlant: '/administration/static/img/cms/preview_plant_large.jpg',
        previewPlantSmall: '/administration/static/img/cms/preview_plant_small.jpg',
        previewGlasses: '/administration/static/img/cms/preview_glasses_large.jpg',
        previewGlassesSmall: '/administration/static/img/cms/preview_glasses_small.jpg',
        previewNature: '/administration/static/img/cms/preview_nature_large.jpg',
        previewNatureSmall: '/administration/static/img/cms/preview_nature_small.jpg'
    }
};
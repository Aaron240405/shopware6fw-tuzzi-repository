// SamsultingFashionHomeTheme/src/Resources/app/administration/src/module/sw-cms/elements/product-listing/index.js

// NICHT das Template importieren
// import template from './sw-cms-el-product-listing.html.twig';
// /module/sw-cms/elements/product-listing/index.js
import './config';

// Stattdessen nur die Config-Komponente überschreiben
Shopware.Component.override('sw-cms-el-config-product-listing', {
    methods: {
        createdComponent() {
            this.$super('createdComponent');

            // Erweitere die Konfiguration
            if (!this.element.config.enableCustomArea) {
                this.$set(this.element.config, 'enableCustomArea', {
                    source: 'static',
                    value: false
                });
            }

            if (!this.element.config.customRows) {
                this.$set(this.element.config, 'customRows', {
                    source: 'static',
                    value: []
                });
            }
        }
    }
});

// Die Config Template-Erweiterung in separater Datei
// SamsultingFashionHomeTheme/src/Resources/app/administration/src/module/sw-cms/elements/product-listing/config/sw-cms-el-config-product-listing.html.twig
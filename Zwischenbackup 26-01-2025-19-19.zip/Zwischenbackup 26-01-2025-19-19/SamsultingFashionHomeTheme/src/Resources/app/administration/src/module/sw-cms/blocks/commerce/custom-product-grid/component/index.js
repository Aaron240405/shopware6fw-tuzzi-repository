import template from './sw-cms-block-custom-product-grid.html.twig';
import './sw-cms-block-custom-product-grid.scss';

/**
 * @private
 * @package buyers-experience
 */
export default {
    template,

    compatConfig: Shopware.compatConfig,
};
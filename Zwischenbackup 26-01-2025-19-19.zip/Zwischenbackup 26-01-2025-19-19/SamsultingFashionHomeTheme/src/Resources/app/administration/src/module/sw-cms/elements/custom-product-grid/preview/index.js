import template from './sw-cms-el-preview-custom-product-grid.html.twig';
import './sw-cms-el-preview-custom-product-grid.scss';

/**
 * @private
 * @package buyers-experience
 */
export default {
    template,

    compatConfig: Shopware.compatConfig,
};

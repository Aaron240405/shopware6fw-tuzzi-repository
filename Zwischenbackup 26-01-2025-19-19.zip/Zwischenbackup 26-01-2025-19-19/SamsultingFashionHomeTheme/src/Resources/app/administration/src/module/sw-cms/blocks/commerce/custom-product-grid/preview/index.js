import template from './sw-cms-preview-custom-product-grid.html.twig';
import './sw-cms-preview-custom-product-grid.scss';

/**
 * @private
 * @package buyers-experience
 */
export default {
    template,

    compatConfig: Shopware.compatConfig,
};
import template from './sw-cms-el-config-image.html.twig';

Shopware.Component.override('sw-cms-el-config-image', {
    template,

    inject: ['repositoryFactory'],

    computed: {
        categoryRepository() {
            return this.repositoryFactory.create('category');
        },

        categoryCriteria() {
            const criteria = new Shopware.Data.Criteria();
            criteria.addAssociation('media'); // Mediendaten der Kategorie laden
            return criteria;
        }
    },

    methods: {
        /**
         * Kategorie-Auswahl-Event
         */
        onChangeCategory(categoryId) {
            this.element.config.categoryId.value = categoryId;
            this.$emit('element-update', this.element); // Element aktualisieren
        }
    }
});
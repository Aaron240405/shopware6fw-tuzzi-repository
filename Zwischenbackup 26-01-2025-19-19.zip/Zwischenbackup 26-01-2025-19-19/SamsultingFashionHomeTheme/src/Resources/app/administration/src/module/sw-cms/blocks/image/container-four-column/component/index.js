import template from './sw-cms-block-container-four-column.html.twig';
import './sw-cms-block-container-four-column.scss';

/**
 * @private
 * @package buyers-experience
 */
export default {
    template,

    compatConfig: Shopware.compatConfig,
};

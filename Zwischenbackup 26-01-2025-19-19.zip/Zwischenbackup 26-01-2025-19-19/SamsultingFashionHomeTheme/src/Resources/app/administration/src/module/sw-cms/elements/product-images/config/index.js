import template from './sw-cms-el-config-product-images.html.twig';
const { Component, Mixin } = Shopware;
Component.register('sw-cms-el-config-product-images', {
    template,
    mixins: [
        Mixin.getByName('cms-element')
    ],
    computed: {
        maxImages: {
            get() {
                return this.element.config.maxImages.value;
            },
            set(value) {
                this.element.config.maxImages.value = value;
                // Wichtig: Element-Update triggern
                this.$emit('element-update', this.element);
            }
        }
    },
    created() {
        this.createdComponent();
    },
    methods: {
        createdComponent() {
            if (!this.element.config) {
                this.element.config = {};
            }
            if (!this.element.config.maxImages) {
                this.element.config.maxImages = {
                    source: 'static',
                    value: 4
                };
            }
        },
        onMaxImagesChange(value) {
            const validValue = Math.min(Math.max(1, value), 12);
            this.maxImages = validValue;
        }
    }
});
// /module/sw-cms/elements/product-listing/config/index.js

import './sw-cms-el-config-product-listing.scss';

// /module/sw-cms/elements/product-listing/config/index.js

// Reine Override-Version ohne Template-Import
Shopware.Component.override('sw-cms-el-config-product-listing', {
    data() {
        return {
            customRows: []
        };
    },

    methods: {
        createdComponent() {
            this.$super('createdComponent');
            
            // Initialize custom config
            if (!this.element.config.enableCustomArea) {
                this.$set(this.element.config, 'enableCustomArea', {
                    source: 'static',
                    value: false
                });
            }
        }
    }
});
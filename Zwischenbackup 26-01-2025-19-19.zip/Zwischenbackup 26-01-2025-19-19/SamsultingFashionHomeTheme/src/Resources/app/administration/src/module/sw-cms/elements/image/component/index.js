const { Component } = Shopware;

// Override des Standard-Image-Elements
Component.override('sw-cms-el-image', {
    methods: {
        /**
         * Bild aus der verknüpften Kategorie laden
         */
        getCategoryMedia(categoryId) {
            const categoryRepository = this.repositoryFactory.create('category');
            categoryRepository.get(categoryId, Shopware.Context.api).then((category) => {
                if (category.media && category.media.length > 0) {
                    this.element.config.media.value = category.media[0]; // Setze das Bild
                }
            });
        },

        /**
         * Initiale Logik erweitern
         */
        createdComponent() {
            this.$super('createdComponent'); // Originale Logik beibehalten
            if (this.element.config.categoryId?.value) {
                this.getCategoryMedia(this.element.config.categoryId.value);
            }
        }
    }
});
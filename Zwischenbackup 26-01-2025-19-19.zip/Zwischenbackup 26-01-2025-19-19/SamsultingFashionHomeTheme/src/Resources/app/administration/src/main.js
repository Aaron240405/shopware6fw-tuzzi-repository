// src/Resources/app/administration/src/main.js
import './module/sw-cms/blocks/text-image/my-image-text-reversed';
import './module/sw-cms/elements/dailymotion';
import './module/sw-cms/elements/category-container-new';
// Import des custom-image Elements
import './module/sw-cms/elements/custom-image';
import './module/sw-cms/blocks/commerce/custom-product-grid';

// Import des custom-image-grid Blocks
import './module/sw-cms/blocks/image/image-custom-column';
import './module/sw-cms/blocks/image/container-two-column';
import './module/sw-cms/blocks/image/container-four-column';
import './module/sw-cms/blocks/image/container-one-column';
import './module/sw-cms/elements/product-image-grid';
import './module/sw-cms/elements/custom-product-grid';
import './module/sw-cms/elements/product-images';
import './module/sw-cms/blocks/commerce/product-listing';

// Register the component globally
Shopware.Component.register('sw-cms-el-product-images', () => import('./module/sw-cms/elements/product-images/component'));
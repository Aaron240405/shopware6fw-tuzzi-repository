Shopware.Component.register('sw-cms-el-custom-product-grid', () => import('./component'));
Shopware.Component.register('sw-cms-el-config-custom-product-grid', () => import('./config'));
Shopware.Component.register('sw-cms-el-preview-custom-product-grid', () => import('./preview'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'custom-product-grid',
    label: 'Custom Product Grid',
    component: 'sw-cms-el-custom-product-grid',
    previewComponent: 'sw-cms-el-preview-custom-product-grid',
    configComponent: 'sw-cms-el-config-custom-product-grid',
    defaultConfig: {
        boxLayout: {
            source: 'static',
            value: 'standard',
        },
        showSorting: {
            source: 'static',
            value: true,
        },
        useCustomSorting: {
            source: 'static',
            value: false,
        },
        availableSortings: {
            source: 'static',
            value: [],
        },
        defaultSorting: {
            source: 'static',
            value: '',
        },
        filters: {
            source: 'static',
            value: 'manufacturer-filter,rating-filter,price-filter,shipping-free-filter,property-filter',
        },
        // eslint-disable-next-line inclusive-language/use-inclusive-words
        propertyWhitelist: {
            source: 'static',
            value: [],
        },
        customRows: {
            source: 'static',
            value: [
                {
                    type: 'standard',  // 'standard', 'stoerer-right', 'stoerer-left'
                    products: [],      // Array von Produkt-IDs
                    stoerer: {        // Optional, nur wenn type nicht 'standard'
                        mediaId: null,
                        url: null,
                        newTab: false
                    }
                }
            ]
        },
        filterEnabled: {
            source: 'static',
            value: true,
        },
        propertyFilter: {
            source: 'static', 
            value: true,
        },
        filterBadges: {
            source: 'static',
            value: true,
        },
    },
});

import template from './sw-cms-el-custom-product-grid.html.twig';
import './sw-cms-el-custom-product-grid.scss';

const { Mixin } = Shopware;

/**
 * @private
 * @package buyers-experience
 */
export default {
    template,

    compatConfig: Shopware.compatConfig,

    mixins: [
        Mixin.getByName('cms-element'),
    ],

    computed: {
        currentDemoProducts() {
            return Shopware.Store.get('cmsPage').currentDemoProducts;
        },

        demoProductCount() {
            return this.currentDemoProducts?.length || 8;
        },

        demoProductElement() {
            return {
                config: {
                    boxLayout: {
                        source: 'static',
                        value: this.element.config.boxLayout.value,
                    },
                    displayMode: {
                        source: 'static',
                        value: 'standard',
                    },
                },
                data: null,
            };
        },

        customRows() {
            return this.element.config.customRows.value || [];
        },
    },

    created() {
        this.createdComponent();
    },

    mounted() {
        this.mountedComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('custom-product-grid');
        },

        mountedComponent() {
            const section = this.$el.closest('.sw-cms-section');

            if (!this.$el?.closest?.classList?.contains) {
                return;
            }

            if (section.classList.contains('is--sidebar')) {
                this.demoProductCount = 6;
            }
        },

        getProduct(index) {
            const product = this.currentDemoProducts?.at(index - 1);

            if (product) {
                return { ...this.demoProductElement, data: { product } };
            }

            return this.demoProductElement;
        },
    },
};

const { Component } = Shopware;

Component.override('sw-cms-el-config-image', {
    // Deine Änderungen und Erweiterungen
});
import template from './sw-cms-block-container-one-column.html.twig';

/**
 * @private
 * @package buyers-experience
 */
export default {
    template,

    compatConfig: Shopware.compatConfig,
};

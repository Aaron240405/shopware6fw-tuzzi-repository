import template from './sw-cms-block-image-custom-column.html.twig';
import './sw-cms-block-image-custom-column.scss';

/**
 * @private
 * @package buyers-experience
 */
export default {
    template,

    compatConfig: Shopware.compatConfig,
};

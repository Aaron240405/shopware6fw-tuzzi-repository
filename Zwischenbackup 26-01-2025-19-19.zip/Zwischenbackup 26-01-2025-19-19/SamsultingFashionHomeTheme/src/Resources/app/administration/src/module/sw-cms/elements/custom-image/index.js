Shopware.Component.register('sw-cms-el-preview-custom-image', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-custom-image', () => import('./config'));
Shopware.Component.register('sw-cms-el-custom-image', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'custom-image',
    label: 'sw-cms.elements.customImage.label',
    component: 'sw-cms-el-custom-image',
    configComponent: 'sw-cms-el-config-custom-image',
    previewComponent: 'sw-cms-el-preview-custom-image',
    defaultConfig: {
        media: {
            source: 'static',
            value: null,
            required: true,
            entity: {
                name: 'media',
            },
        },
        displayMode: {
            source: 'static',
            value: 'cover',
        },
        url: {
            source: 'static',
            value: null,
        },
        newTab: {
            source: 'static',
            value: false,
        },
        minHeight: {
            source: 'static',
            value: '100vh',
        },
        verticalAlign: {
            source: 'static',
            value: null,
        },
        horizontalAlign: {
            source: 'static',
            value: null,
        },
        // NEU hinzugefügte Konfigurationen
        linkType: {
            source: 'static',
            value: 'link', // Standardwert: 'link' oder 'category'
        },
        category: {
            source: 'static',
            value: null, // Standardwert: keine Kategorie zugewiesen
            required: false,
            entity: {
                name: 'category',
            },
        },
        showButton: {
            source: 'static',
            value: true, // Button standardmäßig anzeigen
        },
        buttonText: {
            source: 'static',
            value: 'Mehr erfahren', // Standardtext für den Button
        },
        contentPosition: {
            source: 'static',
            value: 'middle-center', // Default Position
        },
    },
});
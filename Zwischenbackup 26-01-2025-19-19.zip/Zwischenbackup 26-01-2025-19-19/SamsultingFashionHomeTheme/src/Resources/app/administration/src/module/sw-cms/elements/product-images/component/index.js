import template from './sw-cms-el-product-images.html.twig';

const { Component, Mixin } = Shopware;

Component.register('sw-cms-el-product-images', {
    template,

    mixins: [
        Mixin.getByName('cms-element')
    ],

    computed: {
        actualImageCount() {
            if (this.element.config && this.element.config.maxImages && this.element.config.maxImages.value) {
                return parseInt(this.element.config.maxImages.value);
            }
            return 4; // Fallback wenn keine Konfiguration vorhanden
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('product-images');
        }
    }
});
import template from './sw-cms-el-preview-product-images.html.twig';
import './sw-cms-el-preview-product-images.scss';

Shopware.Component.register('sw-cms-el-preview-product-images', {
    template
});
import CMS from '../../../constant/sw-cms.constant';
import template from './sw-cms-el-custom-image.html.twig';
import './sw-cms-el-custom-image.scss';

const { Mixin, Filter } = Shopware;

export default {
    template,

    compatConfig: Shopware.compatConfig,

    inject: [
        'feature',
        'repositoryFactory'  // Wichtig: Repository hier injizieren
    ],

    mixins: [
        Mixin.getByName('cms-element'),
    ],

    data() {
        return {
            categoryData: {
                name: 'Keine Kategorie ausgewählt',
                buttonText: 'Mehr entdecken'
            }
        };
    },

    getDefaultConfig() {
        return {
            media: {
                source: 'static',
                value: null,
                required: true,
                entity: 'media'
            },
            category: {
                source: 'static',
                value: null,
                required: false
            },
            displayMode: {
                source: 'static',
                value: 'standard'
            },
            contentPosition: {
                source: 'static',
                value: 'middle-center'
            },
            verticalAlign: {
                source: 'static',
                value: 'flex-start'  // Für 'Oben'
            },
            horizontalAlign: {
                source: 'static',
                value: 'flex-start'  // Für links ausgerichtet
            },
            minHeight: {
                source: 'static',
                value: ''
            }
        };
    },

    computed: {
        categoryRepository() {
            return this.repositoryFactory.create('category');
        },

        displayModeClass() {
            if (this.element.config.displayMode.value === 'standard') {
                return null;
            }

            return `is--${this.element.config.displayMode.value}`;
        },

        styles() {
            return {
                'min-height':
                    this.element.config.displayMode.value === 'cover' &&
                    this.element.config.minHeight.value &&
                    this.element.config.minHeight.value !== 0
                        ? this.element.config.minHeight.value
                        : '340px',
            };
        },

        imgStyles() {
            return {
                'align-self': this.element.config.verticalAlign.value || null,
            };
        },

        horizontalAlign() {
            return {
                'justify-content': this.element.config.horizontalAlign?.value || null,
            };
        },

        mediaUrl() {
            const fallBackImageFileName = CMS.MEDIA.previewMountain.slice(CMS.MEDIA.previewMountain.lastIndexOf('/') + 1);
            const staticFallBackImage = this.assetFilter(`administration/static/img/cms/${fallBackImageFileName}`);
            const elemData = this.element.data.media;
            const elemConfig = this.element.config.media;

            if (elemConfig.source === 'mapped') {
                const demoMedia = this.getDemoValue(elemConfig.value);

                if (demoMedia?.url) {
                    return demoMedia.url;
                }

                return staticFallBackImage;
            }

            if (elemConfig.source === 'default') {
                const fileName = elemConfig.value?.slice(elemConfig.value.lastIndexOf('/') + 1) ?? '';
                return this.assetFilter(`/administration/static/img/cms/${fileName}`);
            }

            if (elemData?.id) {
                return this.element.data.media.url;
            }

            if (elemData?.url) {
                return this.assetFilter(elemConfig.url);
            }

            return staticFallBackImage;
        },

        assetFilter() {
            return Filter.getByName('asset');
        },

        mediaConfigValue() {
            return this.element?.config?.media?.value;
        },

        previewCategoryName() {
            return this.categoryData.name;
        },
        previewCategoryButtonText() {
            return this.categoryData.buttonText;
        },
    },

    watch: {
        'element.config.category.value': {
            async handler(categoryId) {
                if (!categoryId) {
                    this.categoryData = {
                        name: 'Keine Kategorie ausgewählt',
                        buttonText: 'Mehr entdecken'
                    };
                    return;
                }

                try {
                    const category = await this.categoryRepository.get(categoryId, Shopware.Context.api);
                    this.categoryData = {
                        name: category.name,
                        buttonText: category.customFields?.cta_button_text || 'Mehr entdecken'
                    };
                } catch (error) {
                    console.error('Error loading category:', error);
                    this.categoryData = {
                        name: 'Keine Kategorie ausgewählt',
                        buttonText: 'Mehr entdecken'
                    };
                }
            },
            immediate: true // wieder hinzugefügt
        },

        'cmsPageState.currentDemoEntity': {
            handler() {
                this.updateDemoValue(this.mediaConfigValue);
            },
        },

        mediaConfigValue(value) {
            this.updateDemoValue(value);
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('custom-image');
            this.initElementData('custom-image');

            // Initialisiere category config
            if (!this.element.config.category) {
                this.element.config.category = {
                    source: 'static',
                    value: null
                };
            }
        },

        getPreview() {
            const position = this.element.config.contentPosition.value || 'middle-center';
            
            return `
                <div class="sw-cms-el-custom-image-preview">
                    <img src="${this.mediaUrl}" alt="Preview">
                    ${this.element.config.category.value ? `
                        <div class="preview-overlay position-${position}">
                            <h3>${this.categoryData.name}</h3>
                            ${this.element.config.showButton.value ? `
                                <div class="preview-button">${this.categoryData.buttonText}</div>
                            ` : ''}
                        </div>
                    ` : ''}
                </div>
            `;
        },

        // Neue Methode für Kategorie-Änderungen
        onCategoryChange(categoryId) {
            this.element.config.category.value = categoryId || null;
        },

        updateDemoValue(value) {
            const mediaId = this.element?.data?.media?.id;
            const isSourceStatic = this.element?.config?.media?.source === 'static';

            if (isSourceStatic && mediaId && value !== mediaId) {
                this.element.config.media.value = mediaId;
            }
        },

        async onCategorySelected(urlObject) {
            if (urlObject.entity !== 'category' || !urlObject.id) {
                console.warn('Kein gültiges Kategorie-Objekt ausgewählt.');
                this.element.config.category.value = null;  // Reset falls keine Kategorie gewählt wurde
                return;
            }
        
            try {
                const category = await this.categoryRepository.get(urlObject.id, Shopware.Context.api);
                if (category) {
                    // Setzen der URL und der Kategorie-ID
                    this.element.config.url.value = `/navigation/${category.id}`;
                    this.element.config.category.value = category.id;
        
                    // Optional: Anzeige aktualisieren
                    this.categoryData.name = category.name;
                    this.categoryData.buttonText = category.customFields?.cta_button_text || 'Mehr entdecken';
        
                    console.log(`Kategorie ausgewählt: ${category.name} (ID: ${category.id})`);
                }
            } catch (error) {
                console.error('Fehler beim Laden der Kategorie:', error);
            }
        
            this.$emit('element-update', this.element);
        },
    
        onLinkTypeChange(type) {
            this.element.config.linkType.value = type;
            this.$emit('element-update', this.element);
        },
    },
};
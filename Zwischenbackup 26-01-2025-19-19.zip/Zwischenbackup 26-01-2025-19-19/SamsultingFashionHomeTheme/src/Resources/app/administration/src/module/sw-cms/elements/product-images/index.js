import './component';
import './config';
import './preview';
Shopware.Service('cmsService').registerCmsElement({
    name: 'product-images',
    label: 'Produktbilder',
    component: 'sw-cms-el-product-images',
    configComponent: 'sw-cms-el-config-product-images',
    previewComponent: 'sw-cms-el-preview-product-images',
    defaultConfig: {
        maxImages: {
            source: 'static',
            value: 4
        }
    },
    collect: function(elem) {
        const context = {
            maxImages: {
                source: 'static',
                value: elem.config.maxImages.value
            }
        };
        return context;
    }
});
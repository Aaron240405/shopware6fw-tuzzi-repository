// Registriere die Preview-Komponente
Shopware.Component.register('sw-cms-preview-custom-product-grid', () => import('./preview'));

// Registriere die Block-Komponente
Shopware.Component.register('sw-cms-block-custom-product-grid', () => import('./component'));

// CMS Block in der cmsService registrieren
Shopware.Service('cmsService').registerCmsBlock({
    name: 'custom-product-grid',
    label: 'Custom Product Grid',
    category: 'commerce',
    component: 'sw-cms-block-custom-product-grid',
    previewComponent: 'sw-cms-preview-custom-product-grid',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '20px',
        marginRight: '20px',
        sizingMode: 'boxed',
    },
    slots: {
        left: 'product-box',
        center: 'product-box',
        right: 'product-box',
    },
});
import './component';
import './config';
import './preview';

Shopware.Service('cmsService').registerCmsElement({
    name: 'category-container',
    label: 'sw-cms.elements.categoryContainer.label',
    component: 'sw-cms-el-category-container',
    configComponent: 'sw-cms-el-config-category-container',
    previewComponent: 'sw-cms-el-preview-category-container',
    defaultConfig: {
        media: {
            source: 'static',
            value: null,
            required: true,
            entity: {
                name: 'media'
            }
        },
        displayMode: {
            source: 'static',
            value: 'standard'
        },
        url: {
            source: 'static',
            value: null
        },
        newTab: {
            source: 'static',
            value: false
        },
        minHeight: {
            source: 'static',
            value: '340px'
        },
        verticalAlign: {
            source: 'static',
            value: null
        }
    }
});
import template from './sw-cms-block-container-two-column.html.twig';
import './sw-cms-block-container-two-column.scss';

/**
 * @private
 * @package buyers-experience
 */
export default {
    template,

    compatConfig: Shopware.compatConfig,
};

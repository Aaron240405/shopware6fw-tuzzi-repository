import Plugin from 'src/plugin-system/plugin.class';

export default class CustomDropdownPlugin extends Plugin {
    static options = {
        dropdownSelector: '[data-dropdown]',
        optionsSelector: '.custom-dropdown-options',
        optionSelector: '.custom-dropdown-option',
        selectedSelector: '.custom-dropdown-selected',
        selectedValueSelector: '.selected-value',
        nativeSelectSelector: '.custom-dropdown-native',
        openClass: 'data-dropdown-open'
    };

    init() {
        console.log('Custom Dropdown JS loaded!'); // Debug log
        this.dropdown = this.el.querySelector(this.options.dropdownSelector);
        this.selected = this.el.querySelector(this.options.selectedSelector);
        this.selectedValue = this.el.querySelector(this.options.selectedValueSelector);
        this.options = this.el.querySelector(this.options.optionsSelector);
        this.nativeSelect = this.el.querySelector(this.options.nativeSelectSelector);

        this._registerEvents();
    }

    _registerEvents() {
        // Toggle dropdown
        this.selected.addEventListener('click', this._onToggleDropdown.bind(this));

        // Handle option selection
        this.options.addEventListener('click', this._onOptionClick.bind(this));

        // Close dropdown when clicking outside
        document.addEventListener('click', (event) => {
            if (!this.el.contains(event.target)) {
                this._closeDropdown();
            }
        });
    }

    _onToggleDropdown() {
        const isOpen = this.dropdown.getAttribute(this.options.openClass) === 'true';
        if (isOpen) {
            this._closeDropdown();
        } else {
            this._openDropdown();
        }
    }

    _onOptionClick(event) {
        const option = event.target.closest(this.options.optionSelector);
        if (!option || option.classList.contains('disabled')) return;

        // Update selected value
        const value = option.dataset.value;
        const text = option.textContent.trim();
        
        this.selectedValue.textContent = text;
        
        // Update native select
        this.nativeSelect.value = value;
        
        // Trigger change event
        this.nativeSelect.dispatchEvent(new Event('change', { bubbles: true }));
        
        // Close dropdown
        this._closeDropdown();
    }

    _openDropdown() {
        this.dropdown.setAttribute(this.options.openClass, 'true');
    }

    _closeDropdown() {
        this.dropdown.setAttribute(this.options.openClass, 'false');
    }
}
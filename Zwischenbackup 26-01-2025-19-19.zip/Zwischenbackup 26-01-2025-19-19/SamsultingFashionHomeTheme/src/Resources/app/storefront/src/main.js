// Import das SCSS
import './scss/base.scss';
import './js/samsulting-fashion-home-theme-base.js';
import './js/swiper';
import CustomDropdownPlugin from './js/custom-dropdown.plugin';

// Register plugin
window.PluginManager.register('CustomDropdown', CustomDropdownPlugin, '.custom-dropdown');
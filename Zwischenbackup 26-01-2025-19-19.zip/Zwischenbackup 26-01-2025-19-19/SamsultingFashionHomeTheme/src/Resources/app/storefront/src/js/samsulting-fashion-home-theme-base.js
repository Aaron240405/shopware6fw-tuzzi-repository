document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const header = document.querySelector('.header-main');
    const currentPath = window.location.pathname.toLowerCase();
  
    let isHoveringHeader = false; // Flag, ob der Header gerade gehovered wird
  
    const isHomepage = currentPath === '/' || currentPath === '/de/' || currentPath.includes('home') || currentPath.includes('startseite');
  
    if (isHomepage) {
      console.log('Startseite erkannt');
      body.classList.add('is-ctl-home');
  
      // Scroll-Event
      window.addEventListener('scroll', () => {
        if (window.scrollY > 0) {
          body.classList.add('scrolled');
        } else if (!isHoveringHeader) {
          // `scrolled` nur entfernen, wenn der Header nicht gehovered wird
          body.classList.remove('scrolled');
        }
      });
  
      // Hover-Event für den gesamten Header
      header.addEventListener('mouseenter', () => {
        isHoveringHeader = true; // Hover aktiv
        body.classList.add('scrolled'); // `scrolled` hinzufügen
      });
  
      header.addEventListener('mouseleave', () => {
        isHoveringHeader = false; // Hover beendet
        if (window.scrollY === 0) {
          body.classList.remove('scrolled'); // `scrolled` nur entfernen, wenn oben und kein Hover
        }
      });
    } else {
      console.log('Keine Startseite');
      body.classList.remove('is-ctl-home');
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const categoryHeader = document.querySelector('.category-header');
    
    const isCategoryPage = body.classList.contains('is-ctl-navigation') || 
                          body.classList.contains('is-ctl-category');
    
    const isHomePage = body.classList.contains('is-ctl-home') || 
                      window.location.pathname === '/' || 
                      window.location.pathname === '/de/';
    
    if (isCategoryPage && !isHomePage && categoryHeader) {
        let lastScrollTop = 0;
        const initialThreshold = 3.875 * 16; // 3.875rem in Pixel (1rem = 16px)

        window.addEventListener('scroll', () => {
            const currentScroll = window.scrollY;
            
            if (currentScroll > lastScrollTop) {
                // Scrolling DOWN
                if (lastScrollTop <= initialThreshold) {
                    // Wenn wir vom oberen Bereich kommen, verwenden wir den höheren Schwellenwert
                    if (currentScroll > initialThreshold) {
                        categoryHeader.classList.add('visible');
                    }
                } else {
                    // Im mittleren/unteren Bereich der Seite verwenden wir einen niedrigeren Schwellenwert
                    if (currentScroll > lastScrollTop + 5) { // kleine Toleranz
                        categoryHeader.classList.add('visible');
                    }
                }
            } else if (currentScroll < lastScrollTop) {
                // Scrolling UP
                categoryHeader.classList.remove('visible');
            }

            lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
        });
    }
});


  document.addEventListener('DOMContentLoaded', () => {
    const navItems = document.querySelectorAll('.nav-item'); // Haupt-Navigationspunkte
    const flyout = document.querySelector('.navigation-flyout'); // Flyout-Element
  
    navItems.forEach((navItem) => {
      navItem.addEventListener('mouseenter', () => {
        const flyoutHeight = flyout.scrollHeight; // Tatsächliche Höhe des Inhalts berechnen
        flyout.style.height = `${flyoutHeight}px`; // Höhe setzen, um die Animation zu starten
        flyout.classList.add('is-open'); // `is-open` Klasse hinzufügen
      });
  
      navItem.addEventListener('mouseleave', () => {
        flyout.style.height = '0'; // Höhe auf 0 setzen, um das Flyout zu schließen
        flyout.classList.remove('is-open'); // `is-open` Klasse entfernen
      });
    });
  });




    document.addEventListener("DOMContentLoaded", function () {
        const faqs = document.querySelectorAll(".faq");
    
        faqs.forEach((faq) => {
        faq.addEventListener("click", () => {
            faqs.forEach((f) => (f !== faq ? f.classList.remove("active") : null));
            faq.classList.toggle("active");
        });
        });
    });


    document.addEventListener('DOMContentLoaded', function () {
        const toggleButton = document.getElementById('toggle-button');
        const seoContent = document.getElementById('seo-content');
        // Originalen Text speichern
        const originalText = toggleButton.innerText;

        toggleButton.addEventListener('click', function () {
            const isHidden = seoContent.classList.contains('d-none');
            if (isHidden) {
                seoContent.classList.remove('d-none');
                toggleButton.innerText = 'Weniger anzeigen';
            } else {
                seoContent.classList.add('d-none');
                toggleButton.innerText = originalText; // Ursprünglichen konfigurierten Text verwenden
            }
        });
    });

    document.addEventListener('DOMContentLoaded', function() {
        const checkSwiper = setInterval(function() {
            if (typeof Swiper !== 'undefined') {
                clearInterval(checkSwiper);
                console.log('Swiper wurde geladen, initialisiere...');
                
                new Swiper('.swiper-container', {
                    slidesPerView: 4, // Standardmäßig Desktop
                    spaceBetween: 10,
                    navigation: {
                        nextEl: '.swiper-button-next',
                        prevEl: '.swiper-button-prev',
                    },
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true
                    },
                    breakpoints: {
                        640: {
                            slidesPerView: 1, // 1 Slide auf Mobile (bis 640px)
                            spaceBetween: 10
                        },
                        768: {
                            slidesPerView: 2, // 2 Slides auf kleineren Tablets (bis 768px)
                            spaceBetween: 10
                        },
                        1024: {
                            slidesPerView: 3, // 3 Slides auf größeren Tablets (bis 1024px)
                            spaceBetween: 10
                        },
                        1200: {
                            slidesPerView: 4, // 4 Slides auf Desktop (bis 1200px)
                            spaceBetween: 10
                        },
                    }
                });
            }
        }, 100);
    });


    document.addEventListener('DOMContentLoaded', function() {
        const productBoxes = document.querySelectorAll('.product-box');
        
        productBoxes.forEach(box => {
            const colorButtons = box.querySelectorAll('.variant-color');
            const firstImage = box.querySelector('.first-image');
            const hoverImage = box.querySelector('.hover-image');
            let originalFirstSrc = firstImage?.src;
            let originalHoverSrc = hoverImage?.src;
            
            colorButtons.forEach(button => {
                button.addEventListener('mouseenter', function() {
                    const variantId = this.dataset.variantId;
                    if (!variantId) return;
                    
                    // AJAX call to get variant images
                    fetch(`${window.router['frontend.detail.page']}?productId=${variantId}`)
                        .then(response => response.text())
                        .then(html => {
                            const parser = new DOMParser();
                            const doc = parser.parseFromString(html, 'text/html');
                            const newImages = doc.querySelectorAll('.gallery-slider-item img');
                            
                            if (newImages.length > 0) {
                                if (firstImage) firstImage.src = newImages[0].src;
                                if (hoverImage && newImages.length > 1) {
                                    hoverImage.src = newImages[1].src;
                                }
                            }
                        });
                });
                
                button.addEventListener('mouseleave', function() {
                    if (firstImage) firstImage.src = originalFirstSrc;
                    if (hoverImage) hoverImage.src = originalHoverSrc;
                });
            });
        });
    });
    

    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('.filter-multi-select-button').forEach(button => {
            button.addEventListener('click', (event) => {
                const button = event.target;
                const isPressed = button.getAttribute('aria-pressed') === 'true';
    
                // Schalte den Zustand um
                button.setAttribute('aria-pressed', isPressed ? 'false' : 'true');
    
                // Optional: Hier kannst du deine Filterlogik integrieren
                console.log(`Filter geändert: ${button.getAttribute('data-label')} (${button.getAttribute('aria-pressed')})`);
            });
        });
    });
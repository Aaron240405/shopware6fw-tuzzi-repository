delete process.env.WEBPACK_WATCH;

const { join } = require('path');

module.exports = (config = {}, { buildOptions } = {}) => {
    // Initialisieren des config.module-Objekts
    config.module = config.module || {};
    config.module.rules = config.module.rules || [];

    // Schriftarten-Loader hinzufügen
    config.module.rules.push({
        test: /\.(woff|woff2|ttf|eot|otf)$/,
        use: {
            loader: 'file-loader',
            options: {
                name: '[name].[ext]',
                outputPath: 'assets/fonts/',
                publicPath: `/theme/${buildOptions?.themeName || 'default'}/assets/fonts/`,
            },
        },
    });

    // Entfernen von unbekannten Eigenschaften (falls nötig)
    delete process.env.WEBPACK_WATCH;

    return config;
};
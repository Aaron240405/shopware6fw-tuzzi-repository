<?php declare(strict_types=1);

namespace SamsultingFashionHomeTheme\Core\Content\Product\Cms;

use Shopware\Core\Content\Cms\Aggregate\CmsSlot\CmsSlotEntity;
use Shopware\Core\Content\Cms\DataResolver\CriteriaCollection;
use Shopware\Core\Content\Cms\DataResolver\Element\AbstractCmsElementResolver;
use Shopware\Core\Content\Cms\DataResolver\Element\ElementDataCollection;
use Shopware\Core\Content\Cms\DataResolver\ResolverContext\ResolverContext;
use Shopware\Core\Content\Cms\SalesChannel\Struct\ProductListingStruct;
use Shopware\Core\Content\Product\SalesChannel\Listing\AbstractProductListingRoute;
use Shopware\Core\Content\Product\SalesChannel\Listing\Filter\ManufacturerListingFilterHandler;
use Shopware\Core\Content\Product\SalesChannel\Listing\Filter\PriceListingFilterHandler;
use Shopware\Core\Content\Product\SalesChannel\Listing\Filter\PropertyListingFilterHandler;
use Shopware\Core\Content\Product\SalesChannel\Listing\Filter\RatingListingFilterHandler;
use Shopware\Core\Content\Product\SalesChannel\Listing\Filter\ShippingFreeListingFilterHandler;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\Feature;
use Shopware\Core\Framework\Log\Package;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Symfony\Component\HttpFoundation\Request;

use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\NotFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsAnyFilter;

#[Package('buyers-experience')]
class CustomProductGridResolver extends AbstractCmsElementResolver
{
    private const LOG_FILE = '/var/www/sw6-test-frankwalder-com_shopware6/htdocs/custom/plugins/SamsultingFashionHomeTheme/logs/custom_product_grid_debug.log';


    /**
     * @internal
     */
    public function __construct(
        private readonly AbstractProductListingRoute $listingRoute
    ) {
    }

    private function debugLog($message, $data = []): void 
    {
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[{$timestamp}] {$message}\n";
        if (!empty($data)) {
            $logEntry .= json_encode($data, JSON_PRETTY_PRINT) . "\n";
        }
        $logEntry .= "----------------------------------------\n";
        
        file_put_contents(self::LOG_FILE, $logEntry, FILE_APPEND);
    }

    public function getType(): string
    {
        return 'custom-product-grid';
    }

    public function collect(CmsSlotEntity $slot, ResolverContext $resolverContext): ?CriteriaCollection
    {
        return null;
    }

    public function enrich(CmsSlotEntity $slot, ResolverContext $resolverContext, ElementDataCollection $result): void
    {
        $data = new ProductListingStruct();
        $slot->setData($data);
    
        $request = $resolverContext->getRequest();
        $context = $resolverContext->getSalesChannelContext();
        
        // Basic Criteria
        $criteria = new Criteria();
        $criteria->setTitle('cms::product-listing');
        
        // Custom Rows
        $customRows = $slot->getConfig()['customRows']['value'] ?? [];
        $data->customRows = $customRows;
    
        $navigationId = $this->getNavigationId($request, $context);
        $listing = $this->listingRoute->load($navigationId, $request, $context, $criteria)->getResult();
        $data->setListing($listing);
    }



    private function getNavigationId(Request $request, SalesChannelContext $salesChannelContext): string
    {
        if ($navigationId = $request->get('navigationId')) {
            return $navigationId;
        }

        $params = $request->attributes->get('_route_params');

        if ($params && isset($params['navigationId'])) {
            return $params['navigationId'];
        }

        return $salesChannelContext->getSalesChannel()->getNavigationCategoryId();
    }







}


<?php declare(strict_types=1);

namespace SamsultingFashionHomeTheme\Core\Content\Product;

use Shopware\Core\Content\Product\SalesChannel\Listing\ProductListingLoader;
use Shopware\Core\Content\Product\SalesChannel\Listing\ProductListingResult;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\System\SalesChannel\SalesChannelContext;

class ProductListingLoaderDecorator extends ProductListingLoader
{
    private ProductListingLoader $productListingLoader;

    public function __construct(ProductListingLoader $productListingLoader)
    {
        $this->productListingLoader = $productListingLoader;
    }

    public function load(Criteria $criteria, SalesChannelContext $context): ProductListingResult
    {
        // Füge die Media-Association hinzu
        $criteria->addAssociation('media');

        return $this->productListingLoader->load($criteria, $context);
    }
}
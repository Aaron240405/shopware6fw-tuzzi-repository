<?php declare(strict_types=1);

namespace SamsultingFashionHomeTheme\Core\Content\Media\Cms\Type;

use Shopware\Core\Content\Media\Cms\Type\ImageSliderTypeDataResolver;
use Shopware\Core\Framework\Log\Package;
use Shopware\Core\Content\Cms\Aggregate\CmsSlot\CmsSlotEntity;
use Shopware\Core\Content\Cms\DataResolver\CriteriaCollection;
use Shopware\Core\Content\Cms\DataResolver\ResolverContext\ResolverContext;

#[Package('buyers-experience')]
class ProductImageGridTypeDataResolver extends ImageSliderTypeDataResolver
{
    public function getType(): string
    {
        return 'product-image-grid';
    }

    public function collect(CmsSlotEntity $slot, ResolverContext $resolverContext): ?CriteriaCollection
    {
        return parent::collect($slot, $resolverContext);
    }

    public function enrich(CmsSlotEntity $slot, ResolverContext $resolverContext, ElementDataInterface $data): void
    {
        parent::enrich($slot, $resolverContext, $data);
    }
}
<?php declare(strict_types=1);

namespace SamsultingFashionHomeTheme\Twig;

use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

class VariantExtension extends AbstractExtension
{
    private EntityRepository $productRepository;

    public function __construct(EntityRepository $productRepository)
    {
        $this->productRepository = $productRepository;
    }

    public function getFunctions(): array
    {
        return [
            new TwigFunction('getVariants', [$this, 'getVariants']),
            new TwigFunction('debugParent', [$this, 'debugParent']),
        ];
    }

    public function getVariants(string $productId, SalesChannelContext $context): array
    {
        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('parentId', $productId));
        $criteria->addAssociation('cover.media'); // Sicherstellen, dass Media geladen wird
        $criteria->addAssociation('options.group');

        $variants = $this->productRepository->search($criteria, $context->getContext());
        $result = [];

        foreach ($variants->getElements() as $variant) {
            foreach ($variant->getOptions() as $option) {
                $group = $option->getGroup();
                if ($group && $group->getName() === 'color') {
                    $result[] = [
                        'id' => $variant->getId(),
                        'color' => $option->getColorHexCode(),
                        'name' => $option->getName(),
                        'coverUrl' => $variant->getCover() ? $variant->getCover()->getMedia()->getUrl() : null,
                    ];
                }
            }
        }

        return $result;
    }

    public function debugParent(string $parentId, SalesChannelContext $context): array
    {
        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('id', $parentId));
        $criteria->addAssociation('configuratorSettings.option.group');
        $criteria->addAssociation('children.cover.media');
        $criteria->addAssociation('children.seoUrls');

        $parent = $this->productRepository->search($criteria, $context->getContext())->first();

        $debug = [];
        if ($parent && $parent->getConfiguratorSettings()) {
            foreach ($parent->getConfiguratorSettings() as $setting) {
                $option = $setting->getOption();
                $group = $option ? $option->getGroup() : null;

                // Überprüfen, ob es eine aktive Variante mit dieser Option gibt
                $variantProduct = null;
                if ($parent->getChildren()) {
                    foreach ($parent->getChildren() as $child) {
                        if (in_array($option->getId(), $child->getOptionIds())) {
                            $variantProduct = $child;
                            break;
                        }
                    }
                }

                if ($variantProduct) {
                    $debug[] = [
                        'groupName' => $group ? $group->getName() : null,
                        'optionName' => $option ? $option->getName() : null,
                        'optionColor' => $option ? $option->getColorHexCode() : null,
                        'variantCoverUrl' => $variantProduct->getCover() ? $variantProduct->getCover()->getMedia()->getUrl() : null,
                        'variantId' => $variantProduct->getId(),
                        'seoUrl' => $variantProduct->getSeoUrls() && $variantProduct->getSeoUrls()->first()
                            ? $variantProduct->getSeoUrls()->first()->getSeoPathInfo()
                            : null,
                    ];
                }
            }
        }

        return ['settings' => $debug];
    }
}
<?php declare(strict_types=1);

namespace SamsultingFashionHomeTheme\Twig;

use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

class MediaExtension extends AbstractExtension
{
    private EntityRepository $productMediaRepository;

    public function __construct(EntityRepository $productMediaRepository)
    {
        $this->productMediaRepository = $productMediaRepository;
    }

    public function getFunctions(): array
    {
        return [
            new TwigFunction('getProductMedia', [$this, 'getProductMedia']),
            new TwigFunction('debugMedia', [$this, 'debugMedia'])
        ];
    }

    public function debugMedia(string $productId, SalesChannelContext $context): array
    {
       $criteria = new Criteria();
       $criteria->addAssociation('media');
       $criteria->addFilter(new EqualsFilter('productId', $productId));
       $result = $this->productMediaRepository->search($criteria, $context->getContext());
       
       $debug = [];
       $seenUrls = [];
       
       foreach ($result->getElements() as $productMedia) {
           $url = $productMedia->getMedia() ? $productMedia->getMedia()->getUrl() : null;
           if ($url && !in_array($url, $seenUrls)) {
               $debug[] = [
                   'mediaId' => $productMedia->getMediaId(),
                   'position' => $productMedia->getPosition(),
                   'url' => $url
               ];
               $seenUrls[] = $url;
           }
       }
       
       return $debug;
    }

    public function getVariants(string $productId, SalesChannelContext $context): array
{
    $criteria = new Criteria();
    $criteria->addFilter(new EqualsFilter('parentId', $productId));
    $criteria->addAssociation('cover');
    $criteria->addAssociation('options.group');
    
    $variants = $this->productRepository->search($criteria, $context->getContext());
    $result = [];
    
    foreach ($variants->getElements() as $variant) {
        foreach ($variant->getOptions() as $option) {
            if ($option->getGroup()->getName() === 'color') {
                $result[] = [
                    'id' => $variant->getId(),
                    'color' => $option->getColorHexCode(),
                    'name' => $option->getName(),
                    'coverUrl' => $variant->getCover() ? $variant->getCover()->getMedia()->getUrl() : null
                ];
            }
        }
    }
    
    return $result;
}
}